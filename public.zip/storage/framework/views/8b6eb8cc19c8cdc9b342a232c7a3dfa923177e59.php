<?php echo $__env->make('headers.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type ='text/javascript'>
$(document).ready(function(){

  $('#cred_supplier').hide();

  var supplier = $('#supplier_name').val();

  $( "#ofc_supplier" ).prop( "readonly", true);
  $( "#bal_supplier" ).prop( "readonly", true);
  $( "#loan_stat" ).prop( "readonly", true);

      $('#cred_supplier').fadeIn(1000);

  });
</script>

<?php $__env->startSection('title', "About Cover and Pages"); ?>

<?php echo $__env->make('headers.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="col-md-12">
											 <div class="card ">
													 <div class="card-header ">
															 Google Maps
													 </div>
													 <div class="card-body ">
															 <div id="map" class="map"></div>
													 </div>
											 </div>
									 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
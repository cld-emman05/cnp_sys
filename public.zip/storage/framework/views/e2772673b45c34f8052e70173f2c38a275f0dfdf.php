<?php $__env->startSection('title', "Create Order"); ?>

<?php echo $__env->make('headers.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('main-content'); ?>
<!-- ORDER FORM -->
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class = 'card-header'>
				<table class="table table-hover" style="width:100%">
				<col width="130">
				<col width="80">
					<thead>
						<th width="25%">Order #</th>
						<th width="25%">Date</th>
						<th width="25%">Customer</th>
					</thead>

					<tbody>
						<tr>
						<td>1</td>
						<td><?php echo e(Carbon\Carbon::now()); ?></td>
						<td><a>Crisostomo Ibarra</a></td>
						</tr>
					</tbody>
				</table>

					<hr>
			</div>

			<?php if(count($errors) > 0): ?>
				<div class="alert alert-danger">
				<strong>Whooops!! </strong> There were some problems with your input.<br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
				</div>
			<?php endif; ?>

			<div class="content">
				<form>
				<?php echo $__env->make('order.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</form>

			<div class="clearfix"></div>
			</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
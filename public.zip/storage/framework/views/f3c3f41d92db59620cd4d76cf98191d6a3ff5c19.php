<!doctype html>
<html lang="en">

<head>
	<?php echo $__env->make('headers.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<title>CnP - <?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
	<div class="wrapper">
         <div class="sidebar" data-color="blue">
             <!--
         Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
     -->
							<?php echo $__env->make('layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>

	<div class="main-panel">
		<?php echo $__env->make('layout.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<div class="panel-header panel-header-lg">
				<canvas id="bigDashboardChart"></canvas>
			</div>

			<div class="content">
				<div class="container-fluid">
						<?php echo $__env->yieldContent('main-content'); ?>
					</div>
				</div>

				<footer class="footer">
					<div class="container-fluid">
						<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</footer>
			</div>

		</div>
</body>

</html>

<?php $__env->startSection('title', "Dashboard"); ?>

<?php $__env->startSection('main-content'); ?>
                <div class="card card-map">
					<div class="header">
                        <h4 class="title">Google Maps</h4>
          </div>
					<div class="map">
						<div id="map"></div>
					</div>
				</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<nav>
                        <ul>
                            <li>
                                <a href="https://www.creative-tim.com">
                                    About us
                                </a>
                            </li>
                            <li>
                                <a href="/about-us">
                                    Contact Us
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <div class="copyright">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="#" target="_blank">Cover and Pages Corporation</a>
                    </div>

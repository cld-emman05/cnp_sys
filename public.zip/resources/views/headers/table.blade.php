<!--   Core JS Files   -->
<script src="{{ asset('js/core/jquery.min.js') }}">></script>
<script src="{{ asset('js/core/popper.min.js')  }}">></script>
<script src="{{ asset('js/core/bootstrap.min.js')  }}">></script>
<script src="{{ asset('js/plugins/perfect-scrollbar.jquery.min.js')  }}">></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="{{ asset('js/plugins/bootstrap-switch.js')  }}">></script>
<!--  Google Maps Plugin    -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBA0xOhZ3ynhWgIZHpmMMiBkkV2unWVck0"></script>
<!-- Chart JS -->
<script src="{{ asset('js/plugins/chartjs.min.js')  }}">></script>
<!--  Notifications Plugin    -->
<script src="{{ asset('js/plugins/bootstrap-notify.js')  }}">></script>
<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
<script src="{{ asset('js/now-ui-dashboard.js?v=1.0.0')  }}">></script>
<!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
<script src="{{ asset('demo/demo.js')  }}">></script>
